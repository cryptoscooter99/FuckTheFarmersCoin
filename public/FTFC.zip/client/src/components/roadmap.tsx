import { motion } from "framer-motion";
import Section from "@/components/section";

const phases = [
  {
    title: "Phase 0 — Stealth & Prep",
    bullets: [
      "Deploy token (1,000,000,000 max supply).",
      "Seed initial liquidity, burn LP tokens in tx #1.",
      "0% taxes, trading enabled, contract settings locked/renounced as applicable.",
      "Publish auditable launch txs + docs in GitHub." ,
    ],
  },
  {
    title: "Phase 1 — Day 1 Chaos",
    bullets: [
      "Website live, CTAs wired (Buy / Chart / Copy Contract).",
      "CMC/CG fast‑track submissions & DEX tools listings.",
      "Meme blitz: Twitter, Telegram, stickers, community raids.",
      "Spaces/AMAs with builders and degens.",
    ],
  },
  {
    title: "Phase 2 — Liquidity & Holders",
    bullets: [
      "Market‑maker parameters tuned (slippage guidance).",
      "Community missions → points/roles; leaderboard on site.",
      "Pooled contests funded by donations/merch (no team wallets).",
      "Third‑party trackers/widgets integrated (Dextools, Birdeye, etc.).",
    ],
  },
  {
    title: "Phase 3 — Utility‑Lite",
    bullets: [
      "On‑site tools: contract copier, meme generator, chart embed.",
      "Micro‑integrations (tipping widget, Telegram price bot).",
      "Open‑source small apps that rep the brand (no promises).",
      "First community‑voted burn events (if donations accrue).",
    ],
  },
  {
    title: "Phase 4 — Scale & Listings",
    bullets: [
      "Apply for more aggregators and small CEX listings.",
      "Partnership memes: collabs with artists & projects.",
      "IRL stunts, merch drops, NFT badge for OGs (non‑dilutive).",
      "International community mods and translations.",
    ],
  },
  {
    title: "Phase 5 — Long Game",
    bullets: [
      "Community treasury (donations only) with multi‑sig.",
      "Periodic transparency posts (volume, holders, notable txs).",
      "If volume justifies: explore fee‑less swap UI skin.",
      "Do it live. No promises. Touch grass.",
    ],
  },
];

export default function Roadmap(){
  return (
    <Section id="roadmap" title="Roadmap" className="bg-ftf-purple">
      <ol className="grid gap-4 sm:grid-cols-2">
        {phases.map((p, i) => (
          <motion.li
            key={p.title}
            initial={{ opacity: 0, y: 8 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.25, delay: i * 0.05 }}
            viewport={{ once: true }}
            className="rounded-2xl p-6 bg-ftf-purple/40 border border-white/10 shadow-coin"
          >
            <h3 className="font-display text-2xl mb-2 text-ftf-gold">{p.title}</h3>
            <ul className="list-disc pl-5 space-y-1 opacity-90">
              {p.bullets.map(b => <li key={b}>{b}</li>)}
            </ul>
          </motion.li>
        ))}
      </ol>
    </Section>
  );
}
