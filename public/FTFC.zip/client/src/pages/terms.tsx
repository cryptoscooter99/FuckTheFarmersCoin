import TermsOfFuckery from "../components/terms-of-fuckery";

export default function Terms() {
  return <TermsOfFuckery />;
}